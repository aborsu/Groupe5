#!/bin/bash
# Lance un parseur ftb.lex.out situé dans sxpcfg sur un input donné en argument. Une installation de SYNTAX est nécessaire.
#    usage:
#        train_parser.sh chemin_vers_sxpcfg fichier_input
#
# Fichiers devant être présents:
#   parser.sh (vous êtes ici)
#   une installation de SYNTAX

if [ "$1" == "--help" ]
then

    echo "Lance un parseur ftb.lex.out situé dans sxpcfg sur un input donné en argument. Une installation de SYNTAX est nécessaire.
    usage:
        train_parser.sh chemin_vers_sxpcfg fichier_input"
else
    sed -i "s/ \. / .\n/g" $2
    sed -i "s/ \" / \{\"\}__ponct /g" $2
    cp $2 $1
    cd $1
    ./ftb.lex.out -n 1 -pnt "$2" > output_groupe5.txt
    cd -
    cp "$1/output_groupe5.txt" ./
fi
