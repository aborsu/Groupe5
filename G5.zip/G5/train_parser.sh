#!/bin/bash
# Lance l'extraction de la grammaire et du corpus (main.py).
# Entraîne un parseur externe (SYNTAX) sur la grammaire et le lexique extrait.
#     usage:
#        train_parser.sh chemin_vers_sxpcfg
# Doivent être présents:
#   main.py
#   extraction.py
#   utils.py
#   tree.py
#   train_parser.sh (vous êtes ici)
#   une installation de SYNTAX

if [ "$1" == "--help" ]
then

    echo "Lance l'extraction de la grammaire et du corpus (main.py). Entraîne un parseur externe (SYNTAX) sur la grammaire et le lexique extrait.
     usage:
        train_parser.sh chemin_vers_sxpcfg"
else
    python3 main.py -t ftb6_2.mrg -l "lefff_5000.ftb4tags" "utf8" -l "lexique_cmpnd_TP.txt" "latin1" 
    cp ftb.lex "$1/spec/"
    cp ftb.bnf "$1/spec/"
    cd $1
    make ftb.lex.out
fi


